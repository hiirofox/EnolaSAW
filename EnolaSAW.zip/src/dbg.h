#include <stdio.h>

#include <atlbase.h>
#include <atlcom.h>
#include <comdef.h>

void HResultCheckFailed(HRESULT hr);
void DBG(const char* format, ...);