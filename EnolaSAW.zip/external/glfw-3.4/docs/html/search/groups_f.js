var searchData=
[
  ['version_20and_20error_20reference_0',['Initialization, version and error reference',['../group__init.html',1,'']]],
  ['vulkan_20support_20reference_1',['Vulkan support reference',['../group__vulkan.html',1,'']]]
];
