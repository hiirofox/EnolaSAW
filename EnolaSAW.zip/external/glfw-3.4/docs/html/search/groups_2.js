var searchData=
[
  ['codes_0',['Error codes',['../group__errors.html',1,'']]],
  ['context_20reference_1',['Context reference',['../group__context.html',1,'']]],
  ['cursor_20shapes_2',['Standard cursor shapes',['../group__shapes.html',1,'']]]
];
